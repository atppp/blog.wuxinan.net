    .text
    .org 0
    .globl _start, start

start:
_start:
sysInit:

                 MOV     R1, #0x78
                 MCR     p15, 0, R1,c1,c0
                 MOV     R1, #0
                 MCR     p15, 0, R1,c7,c10, 4
                 MCR     p15, 0, R1,c7,c5
                 MCR     p15, 0, R1,c7,c6

                 MOV     R2, #0x40000000
                 ORR     R1, R2, #6
                 MCR     p15, 0, R1,c9,c1
                 MRC     p15, 0, R1,c9,c1, 1
                 ORR     R1, R1, #6
                 MCR     p15, 0, R1,c9,c1, 1
                 MRC     p15, 0, R1,c1,c0
                 ORR     R1, R1, #0x50000
                 MCR     p15, 0, R1,c1,c0
                 MRS     R1, CPSR
                 BIC     R1, R1, #0x3F
                 ORR     R1, R1, #0xD3
                 MSR     CPSR_cf, R1
                 LDR     R2, =0xC0200000
                 MOV     R1, #0xFFFFFFFF
                 STR     R1, [R2,#0x10C]
                 STR     R1, [R2,#0xC]
                 STR     R1, [R2,#0x1C]
                 STR     R1, [R2,#0x2C]
                 STR     R1, [R2,#0x3C]
                 STR     R1, [R2,#0x4C]
                 STR     R1, [R2,#0x5C]
                 STR     R1, [R2,#0x6C]
                 STR     R1, [R2,#0x7C]
                 STR     R1, [R2,#0x8C]
                 STR     R1, [R2,#0x9C]
                 STR     R1, [R2,#0xAC]
                 STR     R1, [R2,#0xBC]
                 STR     R1, [R2,#0xCC]
                 STR     R1, [R2,#0xDC]
                 STR     R1, [R2,#0xEC]
                 STR     R1, [R2,#0xFC]
                 LDR     R1, =0xC0400000
                 LDR     R2, [R1,#4]
                 ORR     R2, R2, #2
                 STR     R2, [R1,#4]
                 MOV     R3, #0xF

loc_19B0:
                 NOP
                 SUB     R3, R3, #1
                 CMP     R3, #0
                 BNE     loc_19B0
                 LDR     R1, =0xC0400000
                 LDR     R2, =0x430005
                 STR     R2, [R1,#8]
                 NOP
                 NOP
                 NOP
                 ADR     SP, sysInit
                 MOV     R11, #0
                 MOV     R0, #2
                 LDR     R1, =0x9A6F0
                 LDR     R2, =0x9FF00
                 MOV     R3, #0

loc_19F0:
                 ADD     R1, R1, #4
                 CMP     R1, R2
                 STR     R3, [R1]
                 BNE     loc_19F0
		 B	 main

.align 2
fin:
