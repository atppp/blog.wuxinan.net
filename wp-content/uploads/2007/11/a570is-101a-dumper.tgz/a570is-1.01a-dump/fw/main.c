
#include "crc16.h"
#include "md5.h"

void DisableInterrupts()
{
    asm(
         "MRS     R1, CPSR\n"
         "AND     R0, R1, #0x80\n"
         "ORR     R1, R1, #0x80\n"
         "MSR     CPSR_cf, R1\n"
	 :::"r1","r0");
}

void __attribute__((noreturn)) Restart();
void __attribute__((noreturn)) shutdown()
{
    volatile long *p = (void*)0xc02200a0;

    DisableInterrupts();

    *p = 0x44;

    while(1);
}

/*
int GetPhysicalSwitchRAW(int key)
{
    volatile long *p = (void*)(0xc0220000 + (key&0xffff));
    return *p;
}
*/

void idle()
{
    int i;

    for(i=0;i<0x78800;i++){
	asm ("nop\n");
	asm ("nop\n");
	asm ("nop\n");
	asm ("nop\n");
    }
}

// 0xC02200C0 - AF-beam
// 0xC02200C4 - blue
// 0xC02200C8 - orange

#define LED_BLUE 0xc02200c4
#define LED_AF 0xc02200C0
#define LED_PR 0xc02200C8

void led_on()
{
    volatile long *p=(void*)LED_BLUE;
    *p=0x46;
}

void led_off()
{
    volatile long *p=(void*)LED_BLUE;
    *p=0x44;
}

void send_byte(long b)
{
#define DELAY_SYNC   200
#define DELAY_SPACE  50
#define DELAY0       50
#define DELAY1       100

#define nop()   asm("nop\n")
#define on()    *led=0x46
#define off()   *led=0x44
#define delay(value) \
    for (i=0; i<value; ++i) { \
	nop(); \
	nop(); \
    }

#define do_bit(i) \
        on(); \
	if (b&(1<<i)) { \
	    delay(DELAY1); \
	} else { \
            delay(DELAY0); \
        } \
	off(); \
        delay(DELAY_SPACE);

    volatile long *led = (void*)LED_BLUE;
    int i;

    delay(DELAY_SYNC);

    // data bits
    do_bit(0);
    do_bit(1);
    do_bit(2);
    do_bit(3);
    do_bit(4);
    do_bit(5);
    do_bit(6);
    do_bit(7);
}

void panic()
{
    volatile long *p=(void*)LED_PR;
    p[0]=0x46;
    idle();
    shutdown();
}


int main()
{
    volatile long *p;
    long i, b, t, r, j;

    idle();

    p=(void*)0xc02200e0;
    *p=0x46;
/*
2 nops
0x500000 = 393963 samples@48000Hz
0xa00000 = 787915 samples@48000Hz

638795 = 1 sec

1 nop
0xf00000 = 1013021 samples@48000Hz

745270 = 1 sec
*/

#if 0
    for (i=0;i<30000;i++){
        send_byte(0xAA);
    }
#elif 0
	md5_state_t state;
	md5_byte_t digest[16];
	int di;
	char hh[16]="0123456789ABCDEF";

	md5_init(&state);
	md5_append(&state, (const md5_byte_t *)0xffc00000, 0x400000);
	md5_finish(&state, digest);
	send_byte('M');
	send_byte('D');
	send_byte('5');
	for (di = 0; di < 16; ++di) {
		send_byte(hh[digest[di]/16]);
		send_byte(hh[digest[di]%16]);
	}
#else
    for (i=0;i<300;i++){
	send_byte('0');
	send_byte('1');
	send_byte('2');
	send_byte('3');
	send_byte('4');
	send_byte('5');
	send_byte('6');
	send_byte('7');
	send_byte('8');
	send_byte('9');
	send_byte(13);
	send_byte(10);

//	idle();
    }

    long blkn;
    long len = 1024;

//    p=(void*)0xff800000;
    p=(void*)0xffc00000;
    blkn = 0;

    while (blkn<4096){
	long *ptr;
	long crc;

	ptr = (long*) (((char*)p)+blkn*len);

	send_byte(0x0a);
	send_byte(0x55);
	send_byte(0xaa);
	send_byte(0x50);

	t=(long)ptr;
	send_byte(t);
	send_byte(t>>8);
	send_byte(t>>16);
	send_byte(t>>24);

	crc = crc16(0, (unsigned char*) ptr, len);

	// send 4-byte blocks
	for (i=0;i<(len/4);i++){
	    t=ptr[i];
	    send_byte(t);
	    send_byte(t>>8);
	    send_byte(t>>16);
	    send_byte(t>>24);

	}

	//send crc
	send_byte(crc);
	send_byte(crc>>8);
	send_byte(crc);
	send_byte(crc>>8);

	blkn++;
    }
#endif

    idle();

    shutdown();
}
