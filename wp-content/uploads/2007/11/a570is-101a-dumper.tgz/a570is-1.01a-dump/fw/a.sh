arm-elf-gcc -fno-builtin -O2 -Ilib -nostdinc -c entry.s
arm-elf-gcc -fno-builtin -O2 -Ilib -c lib/crc16.c
arm-elf-gcc -fno-builtin -O2 -Ilib -c lib/md5.c
arm-elf-gcc -fno-builtin -O1 -Ilib -c main.c
arm-elf-gcc -fno-builtin -O2 -Ilib -nostdlib -Wl,-N,-Ttext,1900,-Map,main.map -o main.exec entry.o main.o crc16.o md5.o

arm-elf-objcopy -O binary main.exec main
arm-elf-objdump -d main.exec > main.dump

dd if=/dev/zero bs=1k count=100 >>main

./pakwif PS.FIR main 0x314C
