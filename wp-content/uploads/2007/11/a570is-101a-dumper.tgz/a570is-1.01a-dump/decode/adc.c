#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define ST_SYNC         0
#define ST_BIT          1
#define ST_SPACE        2

#define LEVEL_UNK       0
#define LEVEL_HI        1
#define LEVEL_LO        2

#define LEVEL_THRES_HI  0xa0
#define LEVEL_THRES_LO  0x80

#define LEN_SYNC        10
#define LEN_SPACE       1
#define LEN_0           3 
#define LEN_1           6

int get_level(unsigned char v) {
     if (v>=LEVEL_THRES_HI) return LEVEL_HI;
     else if (v<=LEVEL_THRES_LO) return LEVEL_LO;
     else return LEVEL_UNK;
}

int main(int argc, char *argv[]) {
    unsigned char buf[102400];
    FILE *f = fopen(argv[1], "r+b");
    FILE *fo = fopen("dump", "w+b");
    int len=0, p=0, state = ST_SYNC, pp=0;
    int lv, cnt=0, bits, n=0;
    unsigned char byte;

    while (!feof(f)) {
        pp += len;
        len = fread(buf, 1, sizeof(buf), f);
        p=0;
        while (p<len) {
            lv = get_level(buf[p++]);
            if (lv == LEVEL_UNK) continue;
#if 0
            fwrite((lv == LEVEL_HI)?"^":"_",1,1,fo);
            continue;
#endif
            switch (state) {
                case ST_SYNC:
                    if (lv == LEVEL_HI) {
                        ++cnt;
                    } else {
                        if (cnt >= LEN_SYNC) {
                            cnt = 1;
                            state = ST_BIT;
                            bits = 0;
                            byte = 0;
                        } else {
                            cnt = 0;
                            state = ST_SYNC;
                            printf("%06X [0x%08X]: SYNC ERROR!\n", n, pp+p);
                        }
                    }
                    break;
                case ST_BIT:
                    if (lv == LEVEL_LO) {
                        ++cnt;
                    } else {
                        if (cnt >= LEN_1) {
                            cnt = 1;
                            byte |= (1<<bits);
                            if ((++bits) == 8) {
                                fwrite(&byte, 1, 1, fo);
                                state = ST_SYNC;
                                ++n;
                            } else {
                                state = ST_SPACE;
                            }
                        } else if (cnt >= LEN_0) {
                            cnt = 1;
                            if ((++bits) == 8) {
                                fwrite(&byte, 1, 1, fo);
                                state = ST_SYNC;
                                ++n;
                            } else {
                                state = ST_SPACE;
                            }
                        } else {
                            cnt = 1;
                            state = ST_SYNC;
                            printf("%06X [0x%08X]: BIT SYNC ERROR!\n", n, pp+p);
                        }
                    }
                    break;
                case ST_SPACE:
                    if (lv == LEVEL_HI) {
                        ++cnt;
                    } else {
                        if (cnt >= LEN_SPACE) {
                            cnt = 1;
                            state = ST_BIT;
                        } else {
                            cnt = 0;
                            state = ST_SYNC;
                            printf("%06X [0x%08X]: SPACE SYNC ERROR!\n", n, pp+p);
                        }
                    }
                    break;
            }
        }

    }

    fclose(fo);
    fclose(f);
}
