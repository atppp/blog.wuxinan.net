#include <stdlib.h>
#include <stdio.h>
#include <string.h>

static unsigned char *data;
static int len;
static unsigned long base = 0xFFC00000;

#include "crc16.c"

int findsig(int sp)
{
    int i;

    for (i=0;i<(len-sp-4);i++){
	if ((data[sp+i+0] == 0x0a) &&
	    (data[sp+i+1] == 0x55) &&
	    (data[sp+i+2] == 0xaa) &&
	    (data[sp+i+3] == 0x50) )
	    return sp+i;
    }
    return -1;
}

int main()
{
    FILE *f, *fo;
    int r,t, crc;
    unsigned long addr, blk=base;

    f = fopen("dump", "r+b");
    if (!f) {
        perror("Can't open input file");
        exit(1);
    }
    fo = fopen("dump.dat", "r+b");
    if (!fo) {
        fo = fopen("dump.dat", "w+b");
        if (!fo) {
            perror("Can't open input file");
            exit(1);
        }
    }

    fseek(f, 0, SEEK_END);
    len = ftell(f);
    data = malloc(len);
    fseek(f, 0, SEEK_SET);
    r = fread(data,1, len, f);
    printf("read %d bytes... \n", r);

    t = findsig(0);
    while (t>0){
	addr = *(long*)(data+t+4);

        while (blk < addr) {
            printf("MISSED block: %08x\n", blk);
            blk += 1024;
        }

	printf("found SIG at %7d... Base: %08x CRC...", t, addr);
	crc = crc16(0,data+t+8, 1024);
	printf("%04x...", crc);

	if ((*(unsigned short*)(data+t+8+1024) == crc) &&
	    (*(unsigned short*)(data+t+8+1024+2) == crc)){
	    printf("OK!\n");
            fseek(fo, addr-base, SEEK_SET);
            fwrite(data+t+8,1,1024,fo);
	} else {
	    printf("FAIL\n");
	}

	t = findsig(t+8);
        blk += 1024;
    }

//    fwrite(data,1,len,fo);

    fclose(f);
    fclose(fo);
}
